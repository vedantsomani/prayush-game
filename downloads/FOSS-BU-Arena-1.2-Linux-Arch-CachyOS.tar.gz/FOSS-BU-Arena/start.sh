#!/bin/sh
set -eu
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
 echo "Install Python 3 first. On Arch/CachyOS: sudo pacman -Syu --needed python tk iproute2"
 exit 1
fi
if ! python3 -c 'import tkinter' 2>/dev/null; then
 echo "Install tkinter. On Arch/CachyOS: sudo pacman -Syu --needed python tk iproute2"
 exit 1
fi
exec python3 launcher.py
